# GitHub profile installation

1. Create a **public** repository whose name matches your GitHub username exactly (`username/username`).
2. Upload the contents of this kit to that repository, retaining these paths:
   - `README.md`
   - `assets/terminal.gif`
   - `assets/laser-debug.gif`
3. Commit to the default branch.
4. Open `https://github.com/YOUR_USERNAME` to see your profile, replacing `YOUR_USERNAME` with your real username.

## How the animations work

- **Laser debugger:** Custom looping GIF stored in this repository. It fires at `404`, `NULL`, and `BUG` targets and finishes on a green build status. It works automatically; **no GitHub Actions workflow, bots, or credentials** are needed.
- **Terminal:** Custom animated GIF stored in the repository.
- **Typing headline and wave banner:** Displayed through third-party image services. If those services are temporarily unavailable, your remaining README still displays.

## Tips

- GitHub can cache images. If you replace an animation and GitHub still shows an old version, refresh and allow the image cache to update.
- For the best appearance, upload all three files together and keep their folder paths unchanged.
- No employer-specific repositories, company branding, or business website links are included.
