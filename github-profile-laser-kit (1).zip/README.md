<!-- GitHub profile README: publish in a public repository named after your GitHub username. -->

<div align="center">
  <img width="100%" alt="Aung Paing Oo — Software Engineer"
       src="https://capsule-render.vercel.app/api?type=waving&color=0:08142E,55:0F766E,100:2563EB&height=220&section=header&text=Aung%20Paing%20Oo&fontColor=FFFFFF&fontSize=54&fontAlignY=40&animation=fadeIn&desc=SOFTWARE%20ENGINEER&descAlignY=62&descSize=17" />

  <img alt="Animated introduction" src="https://readme-typing-svg.demolab.com?font=Fira+Code&weight=600&size=21&duration=2900&pause=1100&color=13B8A6&center=true&vCenter=true&repeat=true&width=850&height=58&lines=Building+scalable+systems+and+modern+applications;Full-stack+engineering+%7C+Backend+%7C+Infrastructure;Exploring+Flutter%2C+Dart+and+AI+engineering" />

  <p><strong>Building useful software. Engineering for scale.</strong></p>
</div>

<div align="center">
  <img src="./assets/terminal.gif" width="95%" alt="Animated terminal introducing Aung Paing Oo and engineering interests" />
</div>

## 01 / About me

I'm a software engineer focused on **full-stack applications, backend systems, and infrastructure**. I enjoy understanding how systems work end to end—from clean interfaces and APIs to caching, real-time communication, and deployment.

- **Building:** Web applications, APIs, business software, and real-time features
- **Engineering interests:** System design, performance, routing, and infrastructure
- **Currently learning:** Flutter, Dart, Python for AI, and cloud engineering
- **My approach:** Keep it practical, maintainable, and reliable

## 02 / Tech stack

**Languages, frameworks & tools**

<div align="left">
  <img src="https://skillicons.dev/icons?i=ts,js,react,nextjs,nodejs,html,css,tailwind,postgres,redis,docker,linux,nginx,git,github&theme=dark&perline=8" alt="TypeScript, JavaScript, React, Next.js, Node.js, HTML, CSS, Tailwind CSS, PostgreSQL, Redis, Docker, Linux, Nginx, Git, GitHub" />
</div>

**Learning & exploring**

<div align="left">
  <img src="https://skillicons.dev/icons?i=flutter,dart,python,aws&theme=dark&perline=8" alt="Flutter, Dart, Python, AWS" />
</div>

## 03 / What I like to build

| Domain | What interests me |
| :--- | :--- |
| **Modern web applications** | Fast, usable interfaces with React, Next.js, and TypeScript |
| **Backend & systems** | APIs, caching, services, and reliable integrations |
| **Real-time features** | WebSockets, event-driven systems, and live updates |
| **Infrastructure** | Deployment workflows, Linux, Nginx, Docker, and observability |
| **Mobile & AI** | Exploring Flutter apps and practical AI integrations |

## 04 / Debug mode

<div align="center">
  <img src="./assets/laser-debug.gif" width="100%" alt="Animated sci-fi laser debugger shooting down 404, NULL, and BUG errors until the build passes" />
  <br />
  <sub>Detect. Debug. Deploy. Repeat.</sub>
</div>

<div align="center">
  <sub>Always learning. Always shipping.</sub>

  <img width="100%" alt="Footer wave"
       src="https://capsule-render.vercel.app/api?type=waving&color=0:08142E,55:0F766E,100:2563EB&height=110&section=footer" />
</div>
